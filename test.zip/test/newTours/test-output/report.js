$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/sathypan/Desktop/Testing/newTours/src/test/resources/tour.feature");
formatter.feature({
  "line": 1,
  "name": "Validate New tours apllication",
  "description": "",
  "id": "validate-new-tours-apllication",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 8,
  "name": "Enter the details for booking a flight",
  "description": "",
  "id": "validate-new-tours-apllication;enter-the-details-for-booking-a-flight",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 10,
  "name": "the user is on flight reservation page",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "select the passsenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 12
    },
    {
      "cells": [
        "2"
      ],
      "line": 13
    },
    {
      "cells": [
        "3"
      ],
      "line": 14
    },
    {
      "cells": [
        "4"
      ],
      "line": 15
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "the user should enter \"\u003cDeparture\u003e\" and \"\u003cArrival\"\u003e location",
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "click on continue booking",
  "keyword": "Then "
});
formatter.examples({
  "line": 19,
  "name": "",
  "description": "",
  "id": "validate-new-tours-apllication;enter-the-details-for-booking-a-flight;",
  "rows": [
    {
      "cells": [
        "Departure",
        "Arrival"
      ],
      "line": 20,
      "id": "validate-new-tours-apllication;enter-the-details-for-booking-a-flight;;1"
    },
    {
      "cells": [
        "London",
        "Paris"
      ],
      "line": 21,
      "id": "validate-new-tours-apllication;enter-the-details-for-booking-a-flight;;2"
    },
    {
      "cells": [
        "Paris",
        "London"
      ],
      "line": 22,
      "id": "validate-new-tours-apllication;enter-the-details-for-booking-a-flight;;3"
    },
    {
      "cells": [
        "New York",
        "Paris"
      ],
      "line": 23,
      "id": "validate-new-tours-apllication;enter-the-details-for-booking-a-flight;;4"
    },
    {
      "cells": [
        "London",
        "Zurich"
      ],
      "line": 24,
      "id": "validate-new-tours-apllication;enter-the-details-for-booking-a-flight;;5"
    }
  ],
  "keyword": "Examples"
});
formatter.background({
  "line": 3,
  "name": "Login action",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "the user is on login page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "the user enters \"mercury\" and \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 6,
  "name": "user clicks on sign in button",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 21,
  "name": "Enter the details for booking a flight",
  "description": "",
  "id": "validate-new-tours-apllication;enter-the-details-for-booking-a-flight;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 10,
  "name": "the user is on flight reservation page",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "select the passsenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 12
    },
    {
      "cells": [
        "2"
      ],
      "line": 13
    },
    {
      "cells": [
        "3"
      ],
      "line": 14
    },
    {
      "cells": [
        "4"
      ],
      "line": 15
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "the user should enter \"London\" and \"\u003cArrival\"\u003e location",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "click on continue booking",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 3,
  "name": "Login action",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "the user is on login page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "the user enters \"mercury\" and \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 6,
  "name": "user clicks on sign in button",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 22,
  "name": "Enter the details for booking a flight",
  "description": "",
  "id": "validate-new-tours-apllication;enter-the-details-for-booking-a-flight;;3",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 10,
  "name": "the user is on flight reservation page",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "select the passsenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 12
    },
    {
      "cells": [
        "2"
      ],
      "line": 13
    },
    {
      "cells": [
        "3"
      ],
      "line": 14
    },
    {
      "cells": [
        "4"
      ],
      "line": 15
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "the user should enter \"Paris\" and \"\u003cArrival\"\u003e location",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "click on continue booking",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 3,
  "name": "Login action",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "the user is on login page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "the user enters \"mercury\" and \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 6,
  "name": "user clicks on sign in button",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 23,
  "name": "Enter the details for booking a flight",
  "description": "",
  "id": "validate-new-tours-apllication;enter-the-details-for-booking-a-flight;;4",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 10,
  "name": "the user is on flight reservation page",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "select the passsenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 12
    },
    {
      "cells": [
        "2"
      ],
      "line": 13
    },
    {
      "cells": [
        "3"
      ],
      "line": 14
    },
    {
      "cells": [
        "4"
      ],
      "line": 15
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "the user should enter \"New York\" and \"\u003cArrival\"\u003e location",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "click on continue booking",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.background({
  "line": 3,
  "name": "Login action",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "the user is on login page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "the user enters \"mercury\" and \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 6,
  "name": "user clicks on sign in button",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 24,
  "name": "Enter the details for booking a flight",
  "description": "",
  "id": "validate-new-tours-apllication;enter-the-details-for-booking-a-flight;;5",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 10,
  "name": "the user is on flight reservation page",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "select the passsenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 12
    },
    {
      "cells": [
        "2"
      ],
      "line": 13
    },
    {
      "cells": [
        "3"
      ],
      "line": 14
    },
    {
      "cells": [
        "4"
      ],
      "line": 15
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "the user should enter \"London\" and \"\u003cArrival\"\u003e location",
  "matchedColumns": [
    0
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "click on continue booking",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
});