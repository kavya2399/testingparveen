package newTours;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class toursStepDefinition {

	WebDriver driver;
	
	public void setUp()
	{
		System.setProperty("webdriver.chrome.driver","C:\\Users\\sathypan\\Desktop\\chromedriver\\chromedriver.exe");
		driver=new ChromeDriver();
		
	}
	
	@Given("^the user is on login page$")
	public void the_user_is_on_login_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^the user enters \"([^\"]*)\" and \"([^\"]*)\"$")
	public void the_user_enters_and(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^user clicks on sign in button$")
	public void user_clicks_on_sign_in_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^the user is on flight reservation page$")
	public void the_user_is_on_flight_reservation_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^select the passsenger count$")
	public void select_the_passsenger_count(DataTable arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
	    throw new PendingException();
	}

	@Then("^the user should enter \"([^\"]*)\" and \"([^\"]*)\"> location$")
	public void the_user_should_enter_and_location(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^click on continue booking$")
	public void click_on_continue_booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

}
