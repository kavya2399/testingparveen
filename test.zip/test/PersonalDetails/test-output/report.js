$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/sathypan/Desktop/Testing/PersonalDetails/src/test/resources/personalDetails/PersonalDetails.feature");
formatter.feature({
  "line": 1,
  "name": "Personal Details",
  "description": "",
  "id": "personal-details",
  "keyword": "Feature"
});
formatter.before({
  "duration": 2721572100,
  "status": "passed"
});
formatter.scenario({
  "line": 3,
  "name": "Verify the title and text on the page",
  "description": "",
  "id": "personal-details;verify-the-title-and-text-on-the-page",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "the user is on \u0027Personal Details\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "verify the title of the page",
  "keyword": "Then "
});
formatter.step({
  "line": 6,
  "name": "verify the text Step 1: Personal Details\" on the page",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalDetailsStepDefination.the_user_is_on_Personal_Details_page()"
});
formatter.result({
  "duration": 404238000,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.verify_the_title_of_the_page()"
});
formatter.result({
  "duration": 28502300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 21
    }
  ],
  "location": "PersonalDetailsStepDefination.verify_the_text_Step_Personal_Details_on_the_page(int)"
});
formatter.result({
  "duration": 68108400,
  "status": "passed"
});
formatter.after({
  "duration": 1074768400,
  "status": "passed"
});
formatter.before({
  "duration": 1957713500,
  "status": "passed"
});
formatter.scenario({
  "line": 8,
  "name": "Invalid First Name",
  "description": "",
  "id": "personal-details;invalid-first-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 9,
  "name": "the user is on \u0027Personal Details\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 10,
  "name": "the user clicks the \u0027Next\u0027 without entering first name",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "display \u0027Please fill the First Name\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalDetailsStepDefination.the_user_is_on_Personal_Details_page()"
});
formatter.result({
  "duration": 209676800,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.the_user_clicks_the_Next_without_entering_first_name()"
});
formatter.result({
  "duration": 352087300,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.display_Please_fill_the_First_Name()"
});
formatter.result({
  "duration": 2159187700,
  "status": "passed"
});
formatter.after({
  "duration": 784592700,
  "status": "passed"
});
formatter.before({
  "duration": 1387741500,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "Invalid Last Name",
  "description": "",
  "id": "personal-details;invalid-last-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 14,
  "name": "the user is on \u0027Personal Details\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 15,
  "name": "the user clicks the \u0027Next\u0027 without entering last name",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "display \u0027Please fill the Last Name\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalDetailsStepDefination.the_user_is_on_Personal_Details_page()"
});
formatter.result({
  "duration": 152227600,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.the_user_clicks_the_Next_without_entering_last_name()"
});
formatter.result({
  "duration": 665586800,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.display_Please_fill_the_Last_Name()"
});
formatter.result({
  "duration": 2101121500,
  "status": "passed"
});
formatter.after({
  "duration": 612033700,
  "status": "passed"
});
formatter.before({
  "duration": 1295753700,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Invalid Email",
  "description": "",
  "id": "personal-details;invalid-email",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 19,
  "name": "the user is on \u0027Personal Details\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 20,
  "name": "the user enters invalid email format",
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "display \u0027Please enter valid Email Id.\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalDetailsStepDefination.the_user_is_on_Personal_Details_page()"
});
formatter.result({
  "duration": 129012500,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.the_user_enters_invalid_email_format()"
});
formatter.result({
  "duration": 457980400,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.display_Please_enter_valid_Email_Id()"
});
formatter.result({
  "duration": 2280170600,
  "status": "passed"
});
formatter.after({
  "duration": 642735100,
  "status": "passed"
});
formatter.before({
  "duration": 1494962000,
  "status": "passed"
});
formatter.scenario({
  "line": 23,
  "name": "Invalid Contact No",
  "description": "",
  "id": "personal-details;invalid-contact-no",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 24,
  "name": "the user is on \u0027Personal Details\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "the user clicks the \u0027Next\u0027 without entering contact no",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "display \u0027Please fill the Contact No.\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalDetailsStepDefination.the_user_is_on_Personal_Details_page()"
});
formatter.result({
  "duration": 256741500,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.the_user_clicks_the_Next_without_entering_contact_no()"
});
formatter.result({
  "duration": 639884800,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.display_Please_fill_the_Contact_No()"
});
formatter.result({
  "duration": 148617500,
  "status": "passed"
});
formatter.after({
  "duration": 661030100,
  "status": "passed"
});
formatter.before({
  "duration": 1739182000,
  "status": "passed"
});
formatter.scenario({
  "line": 28,
  "name": "Wrong Contact No",
  "description": "",
  "id": "personal-details;wrong-contact-no",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 29,
  "name": "the user is on \u0027Personal Details\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 30,
  "name": "the user enters invalid contact no",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "display \u0027Please enter valid Contact no.\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalDetailsStepDefination.the_user_is_on_Personal_Details_page()"
});
formatter.result({
  "duration": 235541200,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.the_user_enters_invalid_contact_no()"
});
formatter.result({
  "duration": 572096400,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.display_Please_enter_valid_Contact_no()"
});
formatter.result({
  "duration": 2143746700,
  "status": "passed"
});
formatter.after({
  "duration": 701015900,
  "status": "passed"
});
formatter.before({
  "duration": 1210838500,
  "status": "passed"
});
formatter.scenario({
  "line": 33,
  "name": "Invalid Address line1",
  "description": "",
  "id": "personal-details;invalid-address-line1",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 34,
  "name": "the user is on \u0027Personal Details\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 35,
  "name": "the user clicks the \u0027Next\u0027 without entering addr line one",
  "keyword": "When "
});
formatter.step({
  "line": 36,
  "name": "display \u0027Please fill the address line one\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalDetailsStepDefination.the_user_is_on_Personal_Details_page()"
});
formatter.result({
  "duration": 169125300,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.the_user_clicks_the_Next_without_entering_addr_line_one()"
});
formatter.result({
  "duration": 1058729700,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.display_Please_fill_the_address_line_one()"
});
formatter.result({
  "duration": 400012200,
  "status": "passed"
});
formatter.after({
  "duration": 682041700,
  "status": "passed"
});
formatter.before({
  "duration": 1289684100,
  "status": "passed"
});
formatter.scenario({
  "line": 39,
  "name": "Invalid Address line2",
  "description": "",
  "id": "personal-details;invalid-address-line2",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 40,
  "name": "the user is on \u0027Personal Details\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 41,
  "name": "the user clicks the \u0027Next\u0027 without entering addr line two",
  "keyword": "When "
});
formatter.step({
  "line": 42,
  "name": "display \u0027Please fill the address line two\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalDetailsStepDefination.the_user_is_on_Personal_Details_page()"
});
formatter.result({
  "duration": 185675000,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.the_user_clicks_the_Next_without_entering_addr_line_two()"
});
formatter.result({
  "duration": 1077889400,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.display_Please_fill_the_address_line_two()"
});
formatter.result({
  "duration": 304564900,
  "status": "passed"
});
formatter.after({
  "duration": 718758100,
  "status": "passed"
});
formatter.before({
  "duration": 1233952800,
  "status": "passed"
});
formatter.scenario({
  "line": 44,
  "name": "Invalid City",
  "description": "",
  "id": "personal-details;invalid-city",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 46,
  "name": "the user is on \u0027Personal Details\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 47,
  "name": "the user clicks the \u0027Next\u0027 without selecting any data in city",
  "keyword": "When "
});
formatter.step({
  "line": 48,
  "name": "display \u0027Please select city\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalDetailsStepDefination.the_user_is_on_Personal_Details_page()"
});
formatter.result({
  "duration": 147671600,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.the_user_clicks_the_Next_without_selecting_any_data_in_city()"
});
formatter.result({
  "duration": 650241000,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.display_Please_select_city()"
});
formatter.result({
  "duration": 324110200,
  "status": "passed"
});
formatter.after({
  "duration": 761976600,
  "status": "passed"
});
formatter.before({
  "duration": 1255551000,
  "status": "passed"
});
formatter.scenario({
  "line": 51,
  "name": "Invalid State",
  "description": "",
  "id": "personal-details;invalid-state",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 53,
  "name": "the user is on \u0027Personal Details\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 54,
  "name": "the user clicks the \u0027Next\u0027 without selecting any data in state",
  "keyword": "When "
});
formatter.step({
  "line": 55,
  "name": "display \u0027Please select state\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalDetailsStepDefination.the_user_is_on_Personal_Details_page()"
});
formatter.result({
  "duration": 115248600,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.the_user_clicks_the_Next_without_selecting_any_data_in_state()"
});
formatter.result({
  "duration": 689709600,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.display_Please_select_state()"
});
formatter.result({
  "duration": 211559400,
  "status": "passed"
});
formatter.after({
  "duration": 634589400,
  "status": "passed"
});
formatter.before({
  "duration": 1239658500,
  "status": "passed"
});
formatter.scenario({
  "line": 58,
  "name": "Valid Information",
  "description": "",
  "id": "personal-details;valid-information",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 60,
  "name": "the user is on \u0027Personal Details\u0027 page",
  "keyword": "Given "
});
formatter.step({
  "line": 61,
  "name": "the user enters all valid informations",
  "keyword": "When "
});
formatter.step({
  "line": 62,
  "name": "display \u0027Personal details are validated and accepted successfully.\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 63,
  "name": "navigated to \u0027Education Details\u0027 page",
  "keyword": "Then "
});
formatter.match({
  "location": "PersonalDetailsStepDefination.the_user_is_on_Personal_Details_page()"
});
formatter.result({
  "duration": 167754100,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.the_user_enters_all_valid_informations()"
});
formatter.result({
  "duration": 799451000,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.display_Personal_details_are_validated_and_accepted_successfully()"
});
formatter.result({
  "duration": 47547500,
  "status": "passed"
});
formatter.match({
  "location": "PersonalDetailsStepDefination.navigated_to_Education_Details_page()"
});
formatter.result({
  "duration": 280457100,
  "status": "passed"
});
formatter.after({
  "duration": 640509500,
  "status": "passed"
});
});