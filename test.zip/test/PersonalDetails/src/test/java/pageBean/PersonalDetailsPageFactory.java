package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PersonalDetailsPageFactory {

	WebDriver driver;
	
	@FindBy(id="txtFirstName")
	@CacheLookup
	WebElement firstName;
	
	@FindBy(id="txtLastName")
	@CacheLookup
	WebElement lastName;
	
	@FindBy(id="txtEmail")
	@CacheLookup
	WebElement email;
	
	@FindBy(id="txtPhone")
	@CacheLookup
	WebElement phNo;
	
	@FindBy(id="txtAddress1")
	@CacheLookup
	WebElement addr1;
	
	@FindBy(id="txtAddress2")
	@CacheLookup
	WebElement addr2;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(name="state")
	@CacheLookup
	WebElement state;
	
	@FindBy(linkText="Next")
	@CacheLookup
	WebElement next;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}

	public WebElement getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public WebElement getPhNo() {
		return phNo;
	}

	public void setPhNo(String phNo) {
		this.phNo.sendKeys(phNo);
	}

	public WebElement getAddr1() {
		return addr1;
	}

	public void setAddr1(String addr1) {
		this.addr1.sendKeys(addr1);
	}

	public WebElement getAddr2() {
		return addr2;
	}

	public void setAddr2(String addr2) {
		this.addr2.sendKeys(addr2);
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getState() {
		return state;
	}

	public void setState(String state) {
		this.state.sendKeys(state);
	}

	public WebElement getNext() {
		return next;
	}

	public void setNext() {
		this.next.click();
	}

	public PersonalDetailsPageFactory(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}
	
	
	
}
