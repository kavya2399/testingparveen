package educationDetails;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions
(
	features={"C:\\Users\\sathypan\\Desktop\\Testing\\PersonalDetails\\src\\test\\resources\\educationDetails\\EducationDetails.feature"},
glue= {"educationDetails"},
dryRun=false,
monochrome=true,
strict=true,
format= {"pretty","html:test-output"}
)

public class TestRunner {

}
