package educationDetails;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.EducationPageFactory;

public class EducationDetailsStepDefination {
	private WebDriver driver;
	private EducationPageFactory educationFactory;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sathypan\\Desktop\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void close() {
		driver.quit();
	}
	
	@Given("^the user is on Educational Details page$")
	public void the_user_is_on_Educational_Details_page() throws Throwable {
		driver.get("C:\\Users\\sathypan\\Desktop\\Testing\\PersonalDetails\\EducationalDetails.html");
		educationFactory=new EducationPageFactory(driver);
	}

	@Then("^verify the title of the page$")
	public void verify_the_title_of_the_page() throws Throwable {
		String title=driver.getTitle();
		 Assert.assertEquals("Text is not found on page","Educational Details", title);
	}

	@Then("^verify the text 'Step (\\d+): Educational Details' on the page$")
	public void verify_the_text_Step_Educational_Details_on_the_page(int arg1) throws Throwable {
		 String heading=driver.findElement(By.xpath("//h4[@style='font-family: Calibri;']")).getText();
		 Assert.assertEquals("Step 2: Educational Details", heading);
	}

	@When("^Graduation is not selected$")
	public void graduation_is_not_selected() throws Throwable {
	    educationFactory.setGraduation("");
	    educationFactory.setRegisterBtn();
	}

	@Then("^display 'Please Select Graduation'$")
	public void display_Please_Select_Graduation() throws Throwable {
		String expectedRes = "Please Select Graduation";
		String actualRes = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedRes, actualRes);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^percentage is not selected$")
	public void percentage_is_not_selected() throws Throwable {
		educationFactory.setGraduation("BCA");
		educationFactory.setPercent("");
		educationFactory.setRegisterBtn();
	}

	@Then("^display 'Please fill Percentage detail'$")
	public void display_Please_fill_Percentage_detail() throws Throwable {
		String expectedRes = "Please fill Percentage detail";
		String actualRes = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedRes, actualRes);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Passing Year is not selected$")
	public void passing_Year_is_not_selected() throws Throwable {
		educationFactory.setGraduation("BCA");
		educationFactory.setPercent("99");
		educationFactory.setPassYear("");
		educationFactory.setRegisterBtn();
	}

	@Then("^display 'Please fill Passing Year '$")
	public void display_Please_fill_Passing_Year() throws Throwable {
		String expectedRes = "Please fill Passing Year";
		String actualRes = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedRes, actualRes);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Project Name is not selected$")
	public void project_Name_is_not_selected() throws Throwable {
		educationFactory.setGraduation("BCA");
		educationFactory.setPercent("99");
		educationFactory.setPassYear("2019");
		educationFactory.setProjectName("");
		educationFactory.setRegisterBtn();
	}

	@Then("^display 'Please fill Project Name'$")
	public void display_Please_fill_Project_Name() throws Throwable {
		String expectedRes = "Please fill Project Name";
		String actualRes = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedRes, actualRes);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Technologies is not selected$")
	public void technologies_is_not_selected() throws Throwable {
		educationFactory.setGraduation("BCA");
		educationFactory.setPercent("99");
		educationFactory.setPassYear("2019");
		educationFactory.setProjectName("Java");
		educationFactory.setRegisterBtn();

	}

	@Then("^display 'Please Select Technologies Used'$")
	public void display_Please_Select_Technologies_Used() throws Throwable {
		String expectedRes = "Please Select Technologies Used";
		String actualRes = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedRes, actualRes);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Other Technologies is not selected$")
	public void other_Technologies_is_not_selected() throws Throwable {
		educationFactory.setGraduation("BCA");
		educationFactory.setPercent("99");
		educationFactory.setPassYear("2019");
		educationFactory.setProjectName("Selenium");
		educationFactory.setTech();
		educationFactory.setOtherTech("");
		educationFactory.setRegisterBtn();
	}

	@Then("^display 'Please fill other Technologies Used '$")
	public void display_Please_fill_other_Technologies_Used() throws Throwable {
		String expectedRes = "Please fill other Technologies Used";
		String actualRes = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedRes, actualRes);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user enters all valid informations$")
	public void the_user_enters_all_valid_informations() throws Throwable {
		educationFactory.setGraduation("BCA");
		educationFactory.setPercent("99");
		educationFactory.setPassYear("2019");
		educationFactory.setProjectName("Selenium");
		educationFactory.setTechJava();
		educationFactory.setRegisterBtn();

	}

	@Then("^display 'Your Registration Has succesfully done Plz check you registerd email for account activation link !!!'$")
	public void display_Your_Registration_Has_succesfully_done_Plz_check_you_registerd_email_for_account_activation_link() throws Throwable {

		String expectedRes = "Your Registration Has succesfully done Plz check you registerd email for account activation link !!!";
		String actualRes = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedRes, actualRes);
		driver.switchTo().alert().accept();
		driver.close();
	}


}
