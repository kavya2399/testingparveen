package personalDetails;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageBean.PersonalDetailsPageFactory;

public class PersonalDetailsStepDefination {

	private WebDriver driver;
	private PersonalDetailsPageFactory personalFactory;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sathypan\\Desktop\\chromedriver\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@After
	public void close() {
		driver.quit();
	}

	@Given("^the user is on 'Personal Details' page$")
	public void the_user_is_on_Personal_Details_page() throws Throwable {
	    driver.get("C:\\Users\\sathypan\\Desktop\\Testing\\PersonalDetails\\PersonalDetails.html");
	    personalFactory=new PersonalDetailsPageFactory(driver);
	}

	@Then("^verify the title of the page$")
	public void verify_the_title_of_the_page() throws Throwable {
		 String title=driver.getTitle();
		   Assert.assertEquals("Personal Details", title);
	}

	
	@Then("^verify the text Step (\\d+): Personal Details\" on the page$")
	public void verify_the_text_Step_Personal_Details_on_the_page(int arg1) throws Throwable {
		
		String heading=driver.findElement(By.xpath("//h4[@style='font-family:Calibri;']")).getText();
		  Assert.assertEquals("Text is not found on page","Step 1: Personal Details", heading);
		  
		}


	@When("^the user clicks the 'Next' without entering first name$")
	public void the_user_clicks_the_Next_without_entering_first_name() throws Throwable {
	    personalFactory.setFirstName("");
	    personalFactory.setNext();
	}

	@Then("^display 'Please fill the First Name'$")
	public void display_Please_fill_the_First_Name() throws Throwable {
		String expectedRes = "Please fill the First Name";
		String actualRes = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedRes, actualRes);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user clicks the 'Next' without entering last name$")
	public void the_user_clicks_the_Next_without_entering_last_name() throws Throwable {
	    personalFactory.setFirstName("abc");
		personalFactory.setLastName("");
	    personalFactory.setNext();

	}

	@Then("^display 'Please fill the Last Name'$")
	public void display_Please_fill_the_Last_Name() throws Throwable {
		String expectedRes = "Please fill the Last Name";
		String actualRes = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedRes, actualRes);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user enters invalid email format$")
	public void the_user_enters_invalid_email_format() throws Throwable {
		personalFactory.setFirstName("abc");
		personalFactory.setLastName("xyz");
	    personalFactory.setEmail("abc");
	    personalFactory.setNext();
	}

	@Then("^display 'Please enter valid Email Id\\.'$")
	public void display_Please_enter_valid_Email_Id() throws Throwable {
		String expectedRes = "Please enter valid Email Id.";
		String actualRes = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedRes, actualRes);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user clicks the 'Next' without entering contact no$")
	public void the_user_clicks_the_Next_without_entering_contact_no() throws Throwable {
		personalFactory.setFirstName("abc");
		personalFactory.setLastName("xyz");
	    personalFactory.setEmail("abc@gmail.com");
	    personalFactory.setPhNo("");
	    personalFactory.setNext();
	}

	@Then("^display 'Please fill the Contact No\\.'$")
	public void display_Please_fill_the_Contact_No() throws Throwable {
		String expectedRes = "Please fill the Contact No.";
		String actualRes = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedRes, actualRes);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user enters invalid contact no$")
	public void the_user_enters_invalid_contact_no() throws Throwable {
		personalFactory.setFirstName("abc");
		personalFactory.setLastName("xyz");
	    personalFactory.setEmail("abc@gmail.com");
	    personalFactory.setPhNo("676");
	    personalFactory.setNext();
	}

	@Then("^display 'Please enter valid Contact no\\.'$")
	public void display_Please_enter_valid_Contact_no() throws Throwable {
	    
		String expectedRes = "Please enter valid Contact no.";
		String actualRes = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedRes, actualRes);
		driver.switchTo().alert().accept();
		driver.close();
	}

	
	
	@When("^the user clicks the 'Next' without entering addr line one$")
	public void the_user_clicks_the_Next_without_entering_addr_line_one() throws Throwable {
		personalFactory.setFirstName("abc");
		personalFactory.setLastName("xyz");
	    personalFactory.setEmail("abc@gmail.com");
	    personalFactory.setPhNo("9874563210");
	    personalFactory.setAddr1("");
	    personalFactory.setNext();
	}

	@Then("^display 'Please fill the address line one'$")
	public void display_Please_fill_the_address_line_one() throws Throwable {
		String expectedRes = "Please fill the address line 1";
		String actualRes = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedRes, actualRes);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user clicks the 'Next' without entering addr line two$")
	public void the_user_clicks_the_Next_without_entering_addr_line_two() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		personalFactory.setFirstName("abc");
		personalFactory.setLastName("xyz");
	    personalFactory.setEmail("abc@gmail.com");
	    personalFactory.setPhNo("9874563210");
	    personalFactory.setAddr1("hgh");
	    personalFactory.setAddr2("");
	    personalFactory.setNext();
	    }

	@Then("^display 'Please fill the address line two'$")
	public void display_Please_fill_the_address_line_two() throws Throwable {
		String expectedRes = "Please fill the address line 2";
		String actualRes = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedRes, actualRes);
		driver.switchTo().alert().accept();
		driver.close();
	}



	
	@When("^the user clicks the 'Next' without selecting any data in city$")
	public void the_user_clicks_the_Next_without_selecting_any_data_in_city() throws Throwable {
		personalFactory.setFirstName("abc");
		personalFactory.setLastName("xyz");
	    personalFactory.setEmail("abc@gmail.com");
	    personalFactory.setPhNo("9874563210");
	    personalFactory.setAddr1("gfjk");
	    personalFactory.setAddr2("dsuyg");
	    personalFactory.setCity("Select City");
	    personalFactory.setNext();
	}

	@Then("^display 'Please select city'$")
	public void display_Please_select_city() throws Throwable {
		String expectedRes = "Please select city";
		String actualRes = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedRes, actualRes);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user clicks the 'Next' without selecting any data in state$")
	public void the_user_clicks_the_Next_without_selecting_any_data_in_state() throws Throwable {
		personalFactory.setFirstName("abc");
		personalFactory.setLastName("xyz");
	    personalFactory.setEmail("abc@gmail.com");
	    personalFactory.setPhNo("9874563210");
	    personalFactory.setAddr1("gfjk");
	    personalFactory.setAddr2("dsuyg");
	    personalFactory.setCity("Pune");
	    personalFactory.setState("Select State");
	    personalFactory.setNext();
	}

	@Then("^display 'Please select state'$")
	public void display_Please_select_state() throws Throwable {
	   
		String expectedRes = "Please select state";
		String actualRes = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedRes, actualRes);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^the user enters all valid informations$")
	public void the_user_enters_all_valid_informations() throws Throwable {
		personalFactory.setFirstName("abc");
		personalFactory.setLastName("xyz");
	    personalFactory.setEmail("abc@gmail.com");
	    personalFactory.setPhNo("9874563210");
	    personalFactory.setAddr1("gfjk");
	    personalFactory.setAddr2("dsuyg");
	    personalFactory.setCity("Pune");
	    personalFactory.setState("Tamilnadu");
	    personalFactory.setNext();
	}

	@Then("^display 'Personal details are validated and accepted successfully\\.'$")
	public void display_Personal_details_are_validated_and_accepted_successfully() throws Throwable {
	    
		String expectedRes = "Personal details are validated and accepted successfully.";
		String actualRes = driver.switchTo().alert().getText();
		Assert.assertEquals(expectedRes, actualRes);
		driver.switchTo().alert().accept();
		
	}

	@Then("^navigated to 'Education Details' page$")
	public void navigated_to_Education_Details_page() throws Throwable {
	   driver.get("C:\\Users\\sathypan\\Desktop\\Testing\\PersonalDetails\\EducationalDetails.html");
	   driver.close();
	}


	
	
	
	
}
